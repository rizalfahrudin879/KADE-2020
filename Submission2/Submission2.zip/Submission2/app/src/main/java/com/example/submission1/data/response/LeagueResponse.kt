package com.example.submission1.data.response

import com.example.submission1.data.model.League


data class LeagueResponse(
    val leagues: List<League>
)
