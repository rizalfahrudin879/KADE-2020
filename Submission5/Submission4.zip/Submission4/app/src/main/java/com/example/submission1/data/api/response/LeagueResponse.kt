package com.example.submission1.data.api.response

import com.example.submission1.data.entity.League


data class LeagueResponse(
    val leagues: List<League>
)
