package com.example.submission1.data.response

import com.example.submission1.data.model.Team


data class TeamResponse(
    val teams: List<Team>
)